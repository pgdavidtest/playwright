import {test, expect} from '@playwright/test';
//import { LoginPage } from '../pageobjects/LoginPage';
import {LoginPage} from '../pageobjects/LoginPage'
import login from '../utilities/LoginUtilities'



test.describe('Login Test', () => {

    let webContext;
    let page;
    test.beforeAll(async({browser}) => {
        const loginpage = new LoginPage()
        const context =await  browser.newContext()
        page = await context.newPage( )
        await page.goto('/client');
        await loginpage.getEmailField.fill('name')
        //await page.locator('#userEmail').fill('name')
        await page.locator('#userPassword').fill('name')
        //const loginPage = new LoginPage();
        //await loginPage.loginsession('username', 'password')
         //await login.loginsession('username', 'password')
         await context.storageState({path: 'state.json'})
         webContext = await browser.newContext({storageState: 'state.json'})
        //const loginpage = new LoginPage(page);
        
        //loginpage.visitPage();
        //loginpage.validLogin('ade', 'Password1');

    })
    test.beforeEach(async() => {
        page = await webContext.newPage()
       await page.goto('/client')
       //const loginpage = new LoginPage(page)
       //loginpage.visitPage()
       
        
    })

    test('This test valid login', async({page}  ) =>{
       // const loginpage = new LoginPage(page)
        //loginpage.visitPage()
        await page.waitForTimeout(5000)
        expect(page.url()).toContain('login')
        
    })

})