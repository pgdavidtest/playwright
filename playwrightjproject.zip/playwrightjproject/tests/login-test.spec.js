import {test, expect, request} from '@playwright/test';
import { LoginPage } from '../pageobjects/LoginPage';
//import {LoginPage} from '../pageobjects/LoginPage'
import login from '../utilities/LoginUtilities'
import user from '../test-data/UserData.json'
import DynamicData from '../test-data/DynamicData';
import invaliduserdata from '../test-data/InvalidUserData.json'
import APIUtils from '../utilities/APIUtils';
import {PageUtils} from '../utilities/PageUtils'
const cred = invaliduserdata
//const apiutils = new APIUtils(request)

const dynamicdata = new DynamicData()




test.describe('Login Test', () => {
    const username = process.env.User_Name;
    const password = process.env.User_Password;
    let token;
    console.log(username, password)

    test.beforeAll(async() => {
        const apiContext = await  request.newContext()
        const apiutils = new APIUtils(apiContext)
        token = await apiutils.getToken(`${username}`, `${password}`)
        
    })

    test.beforeEach(async({page}) => {
        const pageutils = new PageUtils(page)
        pageutils.storeSessionToken(token)
       await page.goto('/client')
    })

    test.only('This test valid login', async({page}  ) =>{
        const loginpage = new LoginPage(page)
        await loginpage.validLogin(`${username}`, `${password}`);
        await page.waitForTimeout(10000)
        expect(page.url()).toContain('/dashboard')  
    })

    for(const data of cred) {
    test(`This test invalid credential ${data.testtype}`, async({page}  ) =>{
        const loginpage = new LoginPage(page)
        await loginpage.validLogin(`${data.username}`, `${data.password}`);
        expect (await loginpage.getErrorElement(`${data.elementtype}`)).toContainText(`${data.errormessage}`)
    })
    }

    test('Test login through API', async({page}) => {
        await page.goto('/client')
        expect(page.url()).toContain('/dashboard');
        await page.waitForTimeout(5000)

    })
})