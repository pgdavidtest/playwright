import { LoginPage } from "../pageobjects/LoginPage";
//import {browser, newContext} from '@playwright/test'
//let logingpage;

class LoginUtilities {
    
    async loginsession(username, password, {browser}) {
       // const logingpage = new LoginPage()
       let webContext;
        const context =await  browser.newContext()
        const page = await context.newPage()
        await page.locator('#userEmail').fill(username);
        await page.locator('#userPassword').fill(password);
        await context.storageState({path: 'state.json'})
        webContext = await browser.newContext({storageState: 'state.json'})

        //logingpage.emailField.validLogin(username, password)

    }


}
export default new LoginUtilities;