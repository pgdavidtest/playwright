export class PageUtils {

    constructor(page) {
        this.page = page;

    }

    async storeSessionToken(token) {
        await this.page.addInitScript(value => {
            window.localStorage.setItem('token', value)
        }, token)
    }
}