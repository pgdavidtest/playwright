export default class APIUtils {

   /*  constructor(request) { 
        this.request = request
        //this.page = page
        //this.request = request
    }

    async gettoken() {
        this.request = await request.newContext()
        let response = await this.request.post("/api/ecom/auth/login", {
            data: {
               userEmail:'anshika@gmail.com',
               userPassword:'Iamking@000'
            },
        })
        const responseBody = await response.json
        const token = responseBody.token;
        console.log(token)
       // return token
        /* this.page.addInitScript((value) => {
            window.localStorage.setItem('toke', value)
        },token)
        this.page.goto('/client') 
    } */

    constructor(apiContext)
    {
        this.apiContext = apiContext;
        //this.page = page 
        //this.loginPayLoad = loginPayLoad;
        
    }

    async getToken(useremail, userpassword)
     {
        const loginResponse =  await  this.apiContext.post("https://rahulshettyacademy.com/api/ecom/auth/login",
        {
            data: {
                userEmail:useremail,
                userPassword:userpassword
             },

         } )
        const loginResponseJson = await loginResponse.json();
        const token =loginResponseJson.token;
        console.log(token);
        return token;

    }



}