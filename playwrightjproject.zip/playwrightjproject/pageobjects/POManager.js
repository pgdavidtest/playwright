import {LoginPage} from './LoginPage';
import {DashBoardPage} from './DashBoardPage';
import {OrdersHistoryPage} from './OrderHistoryPage';
import {CartPage} from './CartPage';
import {OrdersReviewPage}  from './OrderReviewPage';



export class POManager {

    constructor(page) {
        this.page = page;
        this.loginpage = new LoginPage(page);
        this.dashboardpage = new DashBoardPage(page);
        this.orderhistorypage = new OrdersHistoryPage(page);
        this.cartpage = new CartPage(page);
        this.ordersreviewpage = new OrdersReviewPage(page);
    }

    getLoginPage() {
        return this.loginpage
    }
}