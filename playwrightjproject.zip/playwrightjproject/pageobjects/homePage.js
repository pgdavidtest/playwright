export class LoginPage {

    constructor(page) {
        this.page = page;
        this.emailField = page.locator('#userEmail');
        this.passwordField = page.locator('#userPassword');
        this.submitBtn = page.locator('#login')
    }

    getEmailField() {
        return this.emailField
    }

    getPasswordField() {
        return this.passwordField
    }

    async visitPage () {
        await this.page.goto('/client')
    }

    async validLogin(username, password) {
        await this.emailField.fill(username);
        await this.passwordField.fill(password);
        //await this.submitBtn.click();

    }
}