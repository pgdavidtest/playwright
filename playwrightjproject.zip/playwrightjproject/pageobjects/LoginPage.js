export class LoginPage {

    constructor(page) {
        this.page = page;
        this.emailField = page.locator('#userEmail');
        this.passwordField = page.locator('#userPassword');
        this.submitBtn = page.locator('#login')
        this.toastError = page.locator('[role="alert"]')
        this.inlineError = page.locator('.invalid-feedback')
    }

    getEmailField() {
        return this.emailField
    }

    getPasswordField() {
        return this.passwordField
    }

    getErrorMessage() {
        return this.errorMessage
    }

    async visitPage () {
        await this.page.goto('/client')
    }

    getErrorElement(element) {
        if(element == 'toast') {
            return this.toastError
        }else if(element == 'inline') {
            return this.inlineError
        }  
    }

    async validLogin(username, password) {
        await this.emailField.fill(username);
        await this.passwordField.fill(password);
        await this.submitBtn.click();

    }
}