import {faker} from '@faker-js/faker'

export default class DynamicData {

    constructor() {
        this.firstname = faker.person.firstName();
        this.lastName = faker.person.lastName()
    }

    getFirstName() {
        return this.firstname
    }

    getLastName() {
        return this.lastName
    }


}
